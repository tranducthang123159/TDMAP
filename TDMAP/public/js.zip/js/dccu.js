/* =========================
LOAD ĐỊA CHÍNH CŨ
========================= */

function loadDcCu(data) {

    clearMeasure();

    /* 🔥 SET KTT */
    updateVN2000(108.5);

    if (!data || !data.features || !data.features.length) {
        console.warn("Không có dữ liệu địa chính cũ");
        return;
    }

    // Không cần parse lại data
    let safeData = data;

    safeData.features = safeData.features.filter(f => {
        return (
            f &&
            f.type === "Feature" &&
            f.geometry &&
            f.geometry.type &&
            f.geometry.coordinates
        );
    });

    if (!safeData.features.length) {
        console.warn("Không có feature hợp lệ");
        return;
    }

    // Kiểm tra xem layer đã tồn tại chưa
    const isNewSource = upsertGeoJSONSource("dc_cu", safeData);

    // Nếu là source mới, mới add các layer
    if (isNewSource) {
        /* polygon */
        map.addLayer({
            id: "dc_cu_fill",
            type: "fill",
            source: "dc_cu",
            paint: {
                "fill-color": "#49cbf3",
                "fill-opacity": 0.25
            }
        });

        /* border */
        map.addLayer({
            id: "dc_cu_line",
            type: "line",
            source: "dc_cu",
            paint: {
                "line-color": "#49cbf3",
                "line-width": 2
            }
        });
    }

    /* =========================
    CLICK THỬA
    ========================= */

    map.on("click", "dc_cu_fill", function (e) {

        if (!e.features || e.features.length === 0) {
            alert("Không có thửa!");
            return;
        }

        let feature = e.features[0];

        window.currentFeature = feature;

        highlightParcel(feature);
        showParcelInfo(feature);
        drawParcelMeasure(feature);
    });

    /* =========================
    DOUBLE CLICK
    ========================= */

    map.on("dblclick", "dc_cu_fill", function (e) {

        let lng = e.lngLat.lng;
        let lat = e.lngLat.lat;

        addMarker(lat, lng);
    });

    /* =========================
    ZOOM
    ========================= */

    try {
        let bbox = safeData.bbox; // sử dụng bbox từ backend (meta)

        map.fitBounds([
            [bbox[0], bbox[1]],
            [bbox[2], bbox[3]]
        ], {
            padding: 20
        });
    } catch (e) {
        console.warn("Không thể fitBounds dc_cu:", e);
    }

    /* search nếu có */
    if (typeof initParcelSearch === "function") {
        try {
            initParcelSearch(safeData);
        } catch (e) {
            console.warn("initParcelSearch dc_cu lỗi:", e);
        }
    }
}

/* Hàm dùng chung cho việc upsert source */
function upsertGeoJSONSource(sourceId, data) {
    const source = map.getSource(sourceId);

    if (source) {
        source.setData(data); // update data thay vì xóa rồi add lại
        return false;
    }

    map.addSource(sourceId, {
        type: "geojson",
        data: data,
        tolerance: 1,
        buffer: 0
    });

    return true;
}